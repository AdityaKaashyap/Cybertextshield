// PredictResponse.java
