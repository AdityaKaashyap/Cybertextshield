// RegisterResponse.java
