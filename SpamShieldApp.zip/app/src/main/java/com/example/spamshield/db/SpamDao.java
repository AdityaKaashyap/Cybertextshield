// SpamDao.java
