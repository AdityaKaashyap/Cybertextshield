// SpamBoxActivity.java
