// SpamMessage.java
