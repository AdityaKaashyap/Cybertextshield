// PredictRequest.java
