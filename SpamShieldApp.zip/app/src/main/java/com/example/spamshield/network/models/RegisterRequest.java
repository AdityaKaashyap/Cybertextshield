// RegisterRequest.java
